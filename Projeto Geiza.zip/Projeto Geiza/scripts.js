// Função para atualizar o conteúdo principal com base na opção do menu
function changeContent(event) {
    event.preventDefault();
    const targetSection = this.getAttribute('data-section');
    const contentArea = document.querySelector('.conteudo');

    // Lógica para carregar o cardápio correspondente
    if (cardapio[targetSection]) {
        contentArea.innerHTML = gerarCardapioHTML(targetSection);
        // Adicionar um evento de clique aos botões "Adicionar"
        document.querySelectorAll('.adicionar-btn').forEach(btn => {
            btn.addEventListener('click', adicionarAoCarrinho);
        });
    } else if (targetSection === 'Login') {
        exibirFormularioLogin();
    } else {
        contentArea.innerHTML = '';
    }
}

// Função para criar e exibir o formulário de login
function exibirFormularioLogin() {
    const contentArea = document.querySelector('.conteudo');
    contentArea.innerHTML = ''; // Limpa o conteúdo anterior

    const container = document.createElement('div');
    container.className = 'container';

    const imagemDiv = document.createElement('div');
    imagemDiv.className = 'imagem';

    const imagem = document.createElement('img');
    imagem.src = 'img/login_image.png';
    imagem.alt = 'Imagem de Login';

    imagemDiv.appendChild(imagem);

    const formularioDiv = document.createElement('div');
    formularioDiv.className = 'formulario';

    const titulo = document.createElement('h2');
    titulo.textContent = 'Faça Login';

    const form = document.createElement('form');

    const campoEmail = document.createElement('div');
    campoEmail.className = 'campo';

    const labelEmail = document.createElement('label');
    labelEmail.htmlFor = 'email';
    labelEmail.textContent = 'Email:';

    const inputEmail = document.createElement('input');
    inputEmail.type = 'email';
    inputEmail.id = 'email';
    inputEmail.name = 'email';
    inputEmail.required = true;

    campoEmail.appendChild(labelEmail);
    campoEmail.appendChild(inputEmail);

    const campoSenha = document.createElement('div');
    campoSenha.className = 'campo';

    const labelSenha = document.createElement('label');
    labelSenha.htmlFor = 'senha';
    labelSenha.textContent = 'Senha:';

    const inputSenha = document.createElement('input');
    inputSenha.type = 'password';
    inputSenha.id = 'senha';
    inputSenha.name = 'senha';
    inputSenha.required = true;

    campoSenha.appendChild(labelSenha);
    campoSenha.appendChild(inputSenha);

    const botaoSubmit = document.createElement('button');
    botaoSubmit.type = 'submit';
    botaoSubmit.textContent = 'Entrar';

    const mensagemCadastro = document.createElement('p');
    mensagemCadastro.innerHTML = 'Não tem uma conta? <a href="cadastro.html">Faça Cadastro!</a>';

    form.appendChild(campoEmail);
    form.appendChild(campoSenha);
    form.appendChild(botaoSubmit);

    formularioDiv.appendChild(titulo);
    formularioDiv.appendChild(form);
    formularioDiv.appendChild(mensagemCadastro);

    container.appendChild(imagemDiv);
    container.appendChild(formularioDiv);

    contentArea.appendChild(container);
}

// Adicionar um evento de clique aos links do menu
document.querySelectorAll('.menu-item').forEach(link => {
    link.addEventListener('click', changeContent);
});



// Objeto que representa o cardápio
const cardapio = {
    hamburguers: [
        {
            nome: "Hamburguer Clássico",
            descricao: "Descrição do hamburguer clássico.",
            preco: 10.99,
            imagem: "img/hamb1.png"
        },
        {
            nome: "Hamburguer X-bacon",
            descricao: "Descrição do hamburguer de bacon.",
            preco: 12.99,
            imagem: "img/hamb2.png"
        },
        // Adicione mais hamburguers aqui
    ],
    aperitivos: [
        {
            nome: "Aperitivo 1",
            descricao: "Descrição do aperitivo 1.",
            preco: 5.00,
            imagem: "img/batata fritas.png"
        },
        {
            nome: "Aperitivo 2",
            descricao: "Descrição do aperitivo 2.",
            preco: 7.00,
            imagem: "img/frango.png"
        },
        // Adicione mais aperitivos aqui
    ],
    bebidas: [
        {
            nome: "Bebida 1",
            descricao: "Descrição da bebida 1.",
            preco: 3.50,
            imagem: "img/coca.png"
        },
        {
            nome: "Bebida 2",
            descricao: "Descrição da bebida 2.",
            preco: 12.50,
            imagem: "img/2l.png"
        },
        // Adicione mais bebidas aqui
    ]
};

// Função para gerar o HTML do cardápio
function gerarCardapioHTML(categoria) {
    const lista = cardapio[categoria];
    const listaHtml = lista.map(item => `
        <div class="produto">
            <img src="${item.imagem}" alt="${item.nome}">
            <h3>${item.nome}</h3>
            <p>${item.descricao}</p>
            <p class="preco">R$ ${item.preco.toFixed(2)}</p>
            <button class="adicionar-btn" data-nome="${item.nome}" data-preco="${item.preco}">Adicionar</button>
        </div>
    `).join('');

    return `<h2>Cardápio de ${categoria.charAt(0).toUpperCase() + categoria.slice(1)}</h2><div class="produto-lista">${listaHtml}</div>`;
}

// Adicionar um evento de clique aos links do menu
document.querySelectorAll('.menu-item').forEach(link => {
    link.addEventListener('click', changeContent);
});

// Função para atualizar o conteúdo principal com base na opção do menu
function changeContent(event) {
    event.preventDefault();

    const targetSection = this.getAttribute('data-section');
    const contentArea = document.querySelector('.conteudo');

    // Lógica para carregar o cardápio correspondente
    if (cardapio[targetSection]) {
        contentArea.innerHTML = gerarCardapioHTML(targetSection);
        // Adicionar um evento de clique aos botões "Adicionar"
        document.querySelectorAll('.adicionar-btn').forEach(btn => {
            btn.addEventListener('click', adicionarAoCarrinho);
        });
    } else {
        contentArea.innerHTML = '';
    }
}

// Função para adicionar um produto ao carrinho
function adicionarAoCarrinho() {
    const nome = this.getAttribute('data-nome');
    const preco = parseFloat(this.getAttribute('data-preco'));

    // Implemente aqui a lógica para adicionar o produto ao carrinho
    // Por exemplo, você pode adicionar o produto a um array de pedidos

    // Exemplo: adicionando o produto a um array de pedidos
    const pedido = { nome, preco };
    carrinho.push(pedido);

    // Atualizar o carrinho (implemente essa função)
    atualizarCarrinho();
}

// Função para atualizar o carrinho (você precisa implementar essa função)
function atualizarCarrinho() {
    // Implemente aqui a lógica para atualizar a exibição do carrinho
}



// Array para armazenar os pedidos no carrinho
const carrinho = [];

// Função para atualizar o carrinho e exibi-lo
function atualizarCarrinho() {
    const carrinhoArea = document.querySelector('.carrinho-lista');
    carrinhoArea.innerHTML = ''; // Limpa o carrinho antes de recriá-lo

    carrinho.forEach(item => {
        const itemHtml = `
            <div class="carrinho-item">
                <span class="carrinho-nome">${item.nome}</span>
                <span class="carrinho-preco">R$ ${item.preco.toFixed(2)}</span>
            </div>
        `;
        carrinhoArea.innerHTML += itemHtml;
    });
}

// Função para adicionar um produto ao carrinho
function adicionarAoCarrinho() {
    const nome = this.getAttribute('data-nome');
    const preco = parseFloat(this.getAttribute('data-preco'));

    // Adiciona o produto ao carrinho
    const pedido = { nome, preco };
    carrinho.push(pedido);

    // Atualiza o carrinho
    atualizarCarrinho();
}

// Função para remover um produto do carrinho
function removerDoCarrinho(index) {
    carrinho.splice(index, 1); // Remove o item do carrinho pelo índice
    atualizarCarrinho(); // Atualiza o carrinho após a remoção
}

// Função para atualizar o carrinho e exibi-lo
function atualizarCarrinho() {
    const carrinhoArea = document.querySelector('.carrinho-lista');
    carrinhoArea.innerHTML = ''; // Limpa o carrinho antes de recriá-lo

    carrinho.forEach((item, index) => {
        const itemHtml = `
            <div class="carrinho-item">
                <span class="carrinho-nome">${item.nome}</span>
                <span class="carrinho-preco">R$ ${item.preco.toFixed(2)}</span>
                <button class="adicionar-btn-carrinho remover-btn" onclick="removerDoCarrinho(${index})">Remover</button>
            </div>
        `;
        carrinhoArea.innerHTML += itemHtml;
    });

    

    
    




}




