import express from 'express';
import dotenv from 'dotenv';
import { Stripe } from 'stripe';
import mysql from 'mysql2';

dotenv.config();

// Iniciar o servidor
const app = express();

app.use(express.static('public'));
app.use(express.json());

// Rota principal
app.get('/', (req, res) => {
    res.sendFile('index.html', { root: 'public' });
});

// Configurar a Stripe com a chave secreta
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
    apiVersion: '2020-08-27', // Use a versão mais recente da API
});

const DOMAIN = process.env.DOMAIN;

app.post('/stripe-checkout', async (req, res) => {
    if (!req.body.items || req.body.items.length === 0) {
        return res.status(400).json({ error: 'Nenhum item no carrinho' });
    }

    const lineItems = req.body.items.map((item) => {
        const unitAmount = parseInt(item.price.replace(/[^0-9.-]+/g, '') * 100);
        return {
            price_data: {
                currency: 'brl',
                product_data: {
                    name: item.title,
                    images: [item.productImg],
                },
                unit_amount: unitAmount, // Em centavos
            },
            quantity: item.quantity,
        };
    });

    try {
        const session = await stripe.checkout.sessions.create({
            payment_method_types: ['card'],
            mode: 'payment',
            success_url: `${DOMAIN}/success`,
            cancel_url: `${DOMAIN}/cancel`,
            line_items: lineItems,
            billing_address_collection: 'required',
        });
        res.json({ url: session.url });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Erro ao criar sessão de pagamento' });
    }
});


const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'hamburgueria'
});

db.connect((err) => {
  if (err) {
    console.error('Erro ao conectar ao banco de dados:', err);
  } else {
    console.log('Conexão com o banco de dados estabelecida com sucesso');
  }
});
// Rota de registro de usuário
app.post('/registro', async (req, res) => {
    const { nome, endereco, email, senha } = req.body;
  
    try {
      // Verifique se o email já está em uso
      const [rows] = await db.promise().query('SELECT * FROM usuarios WHERE email = ?', [email]);
      if (rows.length > 0) {
        return res.status(400).json({ message: 'O email já está em uso' });
      }
  
      // Criptografe a senha antes de armazená-la no banco de dados
      const hashedSenha = await bcrypt.hash(senha, 10);
  
      // Insira o novo usuário no banco de dados
      await db.promise().query('INSERT INTO usuarios (nome, endereco, email, senha) VALUES (?, ?, ?, ?)', [nome, endereco, email, hashedSenha]);
  
      return res.status(201).json({ message: 'Usuário registrado com sucesso' });
    } catch (error) {
      console.error(error);
      return res.status(500).json({ message: 'Erro interno do servidor' });
    }
  });

app.listen(3000, () => {
    console.log('Listening on port 3000');
});

