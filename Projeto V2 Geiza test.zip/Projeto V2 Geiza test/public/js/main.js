// Cart
let cartIcon = document.querySelector("#cart-icon");
let cart = document.querySelector(".cart");
let closeCart = document.querySelector("#close-cart");
let cartCount = document.querySelector(".cart-count"); // Selecionar o elemento da contagem
const payBtn = document.querySelector('.btn-buy'); // Adicionado o botão de pagamento

// Carrinho de compras
let cartItems = [];
loadCart();

// Abrir carrinho
cartIcon.onclick = () => {
    cart.classList.add("active");
    displayCartItems();
};

// Fechar carrinho
closeCart.onclick = () => {
    cart.classList.remove("active");
};

if (document.readyState == 'loading') {
    document.addEventListener('DOMContentLoaded', ready);
} else {
    ready();
}

// Função de inicialização
function ready() {
    // Remover o item do carrinho
    var removeCartButtons = document.getElementsByClassName('cart-remove');
    for (var i = 0; i < removeCartButtons.length; i++) {
        var button = removeCartButtons[i];
        button.addEventListener("click", removeCartItem);
    }
    var quantityInputs = document.getElementsByClassName('cart-quantity');
    for (var i = 0; i < quantityInputs.length; i++) {
        var input = quantityInputs[i];
        input.addEventListener('change', quantityChanged);
    }
    // Adicionar ao carrinho
    var addCart = document.getElementsByClassName('add-cart');
    for (var i = 0; i < addCart.length; i++) {
        var button = addCart[i];
        button.addEventListener("click", addCartClicked);
    }
    // Botão "Pedir Agora"
    payBtn.addEventListener('click', buyButtonClicked);
}

// Função de compra
function buyButtonClicked() {
    // Redirecionar para a página de pagamento
    fetch('/stripe-checkout', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            items: cartItems,
        }),
    })
    .then((res) => res.json())
    .then((data) => {
        window.location.href = data.url;
    })
    .catch((error) => {
        console.error('Erro ao processar pagamento:', error);
    });
}

// Remover o item do carrinho
function removeCartItem(event) {
    var buttonClicked = event.target;
    var productTitle = buttonClicked.parentElement.querySelector('.cart-product-title').innerText;
    removeItemFromCart(productTitle);
    buttonClicked.parentElement.remove();
    updateTotal();
}

// Alterar quantidade do item
function quantityChanged(event) {
    var input = event.target;
    var productTitle = input.parentElement.querySelector('.cart-product-title').innerText;
    var quantity = parseInt(input.value);
    updateItemQuantity(productTitle, quantity);
    updateTotal();
}

// Adicionar ao carrinho
function addCartClicked(event) {
    var button = event.target;
    var shopProduct = button.parentElement;
    var title = shopProduct.querySelector('.product-title').innerText;
    var price = shopProduct.querySelector('.price').innerText;
    var productImg = shopProduct.querySelector('.product-img').src;

    // Extrair o valor do preço e formatá-lo corretamente
    var priceValue = parseFloat(price.replace('R$', '').replace(',', '.'));

    // Arredondar para dois decimais e multiplicar por 100 para centavos
    var priceInCents = Math.round(priceValue * 100);

    addItemToCart(title, priceInCents, productImg);
    updateTotal();
}

// Remover o item do carrinho
function removeCartItem(event) {
    var buttonClicked = event.target;
    var productTitle = buttonClicked.parentElement.querySelector('.cart-product-title').innerText;
    removeItemFromCart(productTitle);
    buttonClicked.parentElement.remove();
    updateTotal();
}

// Alterar quantidade do item
function quantityChanged(event) {
    var input = event.target;
    var productTitle = input.parentElement.querySelector('.cart-product-title').innerText;
    var quantity = parseInt(input.value);
    updateItemQuantity(productTitle, quantity);
    updateTotal();
}

// Adicionar ao carrinho
function addCartClicked(event) {
    var button = event.target;
    var shopProduct = button.parentElement;
    var title = shopProduct.querySelector('.product-title').innerText;
    var price = shopProduct.querySelector('.price').innerText;
    var productImg = shopProduct.querySelector('.product-img').src;

    addItemToCart(title, price, productImg);
    updateTotal();
}

// Adicionar item ao carrinho
function addItemToCart(title, price, productImg) {
    var item = {
        title: title,
        price: price,
        img: productImg,
        quantity: 1
    };
    cartItems.push(item);
    saveCart();
    updateCartCount(); // Atualiza a contagem
}

// Atualizar a quantidade de um item no carrinho
function updateItemQuantity(title, quantity) {
    for (var i = 0; i < cartItems.length; i++) {
        if (cartItems[i].title === title) {
            cartItems[i].quantity = quantity;
            break;
        }
    }
    saveCart();
    updateCartCount(); // Atualiza a contagem
}

// Remover um item do carrinho
function removeItemFromCart(title) {
    for (var i = 0; i < cartItems.length; i++) {
        if (cartItems[i].title === title) {
            cartItems.splice(i, 1);
            break;
        }
    }
    saveCart();
    updateCartCount(); // Atualiza a contagem
}

// Limpar o carrinho
function clearCart() {
    cartItems = [];
    saveCart();
    displayCartItems();
    updateCartCount(); // Atualiza a contagem
}

// Atualizar o carrinho
function updateTotal() {
    var cartContent = document.getElementsByClassName("cart-content")[0];
    while (cartContent.hasChildNodes()) {
        cartContent.removeChild(cartContent.firstChild);
    }

    var total = 0;
    for (var i = 0; i < cartItems.length; i++) {
        var item = cartItems[i];
        var cartBox = document.createElement('div');
        cartBox.classList.add('cart-box');
        var cartBoxContent = `
            <img src="${item.img}" alt="" class="cart-img">
            <div class="detail-box">
                <div class="cart-product-title">${item.title}</div>
                <div class="cart-price">${item.price}</div>
                <input type="number" value="${item.quantity}" class="cart-quantity">
            </div>
            <i class='bx bxs-trash-alt cart-remove'></i>
        `;
        cartBox.innerHTML = cartBoxContent;
        cartContent.appendChild(cartBox);
        cartBox.querySelector('.cart-remove').addEventListener('click', removeCartItem);
        cartBox.querySelector('.cart-quantity').addEventListener('change', quantityChanged);

        total += parseFloat(item.price.replace("R$", "").replace(",", ".")) * item.quantity;
    }

    var formattedTotal = 'R$' + total.toFixed(2).replace('.', ',');
    document.querySelector(".total-price").innerText = formattedTotal;
}

// Salvar carrinho no armazenamento local (localStorage)
function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cartItems));
}

// Carregar carrinho do armazenamento local (localStorage)
function loadCart() {
    var storedCart = localStorage.getItem('cart');
    if (storedCart) {
        cartItems = JSON.parse(storedCart);
    }
}

// Exibir itens do carrinho
function displayCartItems() {
    var cartContent = document.getElementsByClassName("cart-content")[0];
    while (cartContent.hasChildNodes()) {
        cartContent.removeChild(cartContent.firstChild);
    }

    for (var i = 0; i < cartItems.length; i++) {
        var item = cartItems[i];
        var cartBox = document.createElement('div');
        cartBox.classList.add('cart-box');
        var cartBoxContent = `
            <img src="${item.img}" alt="" class="cart-img">
            <div class="detail-box">
                <div class="cart-product-title">${item.title}</div>
                <div class="cart-price">${item.price}</div>
                <input type="number" value="${item.quantity}" class="cart-quantity">
            </div>
            <i class='bx bxs-trash-alt cart-remove'></i>
        `;
        cartBox.innerHTML = cartBoxContent;
        cartContent.appendChild(cartBox);
        cartBox.querySelector('.cart-remove').addEventListener('click', removeCartItem);
        cartBox.querySelector('.cart-quantity').addEventListener('change', quantityChanged);
    }
    updateTotal();
}

// Atualizar a contagem do carrinho
function updateCartCount() {
    cartCount.innerText = cartItems.reduce((total, item) => total + item.quantity, 0).toString();
}

// Inicialização: Carregar carrinho e exibir itens
loadCart();
displayCartItems();
updateCartCount(); // Atualiza a contagem inicial

// Abrir o formulário de registro
document.querySelector('a[href="cadastro.html"]').addEventListener('click', (e) => {
    e.preventDefault();
    document.querySelector('.registro-form').style.display = 'block';
});

// Enviar o formulário de registro
document.getElementById('registro-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const nome = document.getElementById('nome').value;
    const endereco = document.getElementById('endereco').value;
    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;

    const response = await fetch('/registro', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ nome, endereco, email, senha })
    });

    if (response.ok) {
        alert('Usuário registrado com sucesso!');
        // Limpar os campos após o registro
        document.getElementById('nome').value = '';
        document.getElementById('endereco').value = '';
        document.getElementById('email').value = '';
        document.getElementById('senha').value = '';
        document.querySelector('.registro-form').style.display = 'none';
    } else {
        const data = await response.json();
        alert(data.message);
    }
});
